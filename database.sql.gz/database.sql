PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE prices (timestamp INTEGER, itemkey TEXT, price REAL);
COMMIT;
