PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "pricesV2" (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp INTEGER,
                        itemkey TEXT,
                        base_key TEXT,
                        unitprice REAL,
                        count INTEGER,
                        recomb INTEGER,
                        color TEXT,
                        name TEXT,
                        ench TEXT,
                        raw_item_bytes TEXT,
                        full_nbt_json TEXT
                    );
CREATE TABLE item_enchants (price_id INTEGER, enchant TEXT, level INTEGER);
CREATE TABLE item_attributes (price_id INTEGER, attribute TEXT, value INTEGER);
CREATE TABLE item_rarities (price_id INTEGER, rarity TEXT);
CREATE TABLE item_reforges (price_id INTEGER, reforge TEXT);
CREATE TABLE item_gems (price_id INTEGER, gem TEXT, quality INTEGER);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('pricesV2',0);
CREATE INDEX idx_pricesV2_itemkey ON pricesV2(itemkey);
CREATE INDEX idx_pricesV2_timestamp ON pricesV2(timestamp);
COMMIT;
